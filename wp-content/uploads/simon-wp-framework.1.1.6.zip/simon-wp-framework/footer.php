<div style="clear: both"></div>
<!-- start footer -->
<div id="footer">
    <p>Copyright &copy; <?php the_date('Y'); ?> <a href="<?php echo get_settings('home'); ?>/">
      <?php bloginfo('name'); ?>
      </a> &middot; <a href="http://www.simonwebdesign.com/simon-wordpress-framework">Simon WordPress Framework</a> by <a href="http://www.simonwebdesign.com">Simon</a> &middot;
      <?php wp_loginout(); ?>
    </p>
</div>
<!-- end footer -->
<?php wp_footer(); ?>
</div>
</body>
</html>