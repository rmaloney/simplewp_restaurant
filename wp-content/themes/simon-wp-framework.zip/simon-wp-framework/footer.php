<div style="clear: both"></div>
<!-- start footer -->
<div id="footer">
    <p>Copyright &copy; <?php the_date('Y'); ?> <a href="<?php echo get_settings('home'); ?>/">
      <?php bloginfo('name'); ?>
       Eagle Village Shops 503 W Lancaster Ave. Wayne, PA 19087 Phone: (610)688-7646 
    </p>
</div>
<!-- end footer -->
<?php wp_footer(); ?>
</div>
</body>
</html>