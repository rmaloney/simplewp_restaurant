<div id ="home_feature" class="grid_12 ">
    <p> The Silverspoon is a New American restaurant and catering business on the Main Line </p>


    <p> We constantly seek out locally grown, organic produce, sustainable fish and humanely raised meats for our menus.     </p>

<a href="#" class="button big">Menus and Information</a>


</div>



<div class="clear"> </div>
<div  id="email_signup" class="grid_4">
    [customcontact form=2]
</div>

<div id="news_post" class="grid_4">
  [tpg_get_posts numerposts=2]
</div>

<div id="other" class="grid_3">
<p> Some ill shit here </p>
</div>





