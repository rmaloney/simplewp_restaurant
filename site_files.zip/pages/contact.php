<div class="grid_5">
    <h4 class="red"> Come visit the Silverspoon. </h4>
      <p> We're located in Eagle Village Shops in Wayne, PA. Our address is:</p> 

      <p> <strong>503 W. Lancaster Ave. Wayne PA 19087</strong><p>

      <p class="red"> <strong> Hours </strong> </p>
        <p> Breakfast/Lunch 10AM - 3PM </p>
       <p> Dinner Tue-Sat 5:30PM - 10pm </p>
        <p>Brunch Sat & Sun 11am - 3pm </p>


       </div>
   
<div class="grid_5">
    <script src="http://www.gmodules.com/ig/ifr?url=http://hosting.gmodules.com/ig/gadgets/file/114281111391296844949/driving-directions.xml&amp;up_fromLocation=&amp;up_myLocations=503%20W%20Lancaster%20Ave.%20Wayne%2C%20PA&amp;up_defaultDirectionsType=&amp;up_autoExpand=&amp;synd=open&amp;w=320&amp;h=55&amp;title=Get+Directions+to+the+Silverspoon&amp;brand=light&amp;lang=en&amp;country=US&amp;border=%23ffffff%7C3px%2C1px+solid+%23999999&amp;output=js"></script>
</div>

   <div class="grid_5 " id="email_form">
      [customcontact form=1]
   </div>


   
  <div class="clear"></div>
