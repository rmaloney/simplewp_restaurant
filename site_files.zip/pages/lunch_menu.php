<div class="grid_5">
	<p><strong> Starters </strong></p>
		<p>Steamed mussels, tomato, fennel, grill bread</p>
		<p>Shrimp stuffed risotto balls, tomato jus, balsamic onions</p>  
		<p>Trio of dips, hummus, artichoke, baba ganoush, pita</p>

	<p><strong>Soups and Salads</strong></p>
		<p>Soup du Jour  </p>
		<p>Wild mushroom soup, fennel crouton, chili oil </p>
		<p>Poached wild shrimp, chickpea, feta, watercress, citrus vinaigrette  </p>
		<p>Caesar Salad, romaine, romano tuilles, anchovy     
		Mixed greens, pickled red onions, cucumber, 
		balsamic vinaigrette  
		Spinach, goat cheese, beets, walnuts, bacon, 
		red wine vinaigrette  </p>

		add chicken     add shrimp or salmon cake 

		<p><strong> Late Breakfast</strong> </p>

		<p>Scramble of the day, house potatoes </p> 
			<p>Crab Omelette, watercress, roasted peppers, artichoke pesto house potatoes </p> 
			<p>Wild mushroom benedict, truffled mornay, spinach, 
			house potatoes </p> 
			<p>French toast, stuffed brioche, cinnamon whipped cream, apple sage compote </p>

		<p><strong> Flatbread of the day </strong></p>
</div>
<div class="grid_5">
		<p> <strong>Sandwiches</strong> </p>
			<p>Country ham and gruyere melt, apple sage compote, 
				pita    w/egg mornay  </p>
			<p>BLT, carmelized pepper bacon, romaine, oven dried tomato, aioli, pumpernickel </p> 
			<p>add egg    add turkey    add chicken </p>
			<p>Shrimp salad, celery root-apple slaw, toasted brioche  </p>
			<p>Grilled chicken, baba ganoush, roasted red pepper, 
		      goat cheese, balsamic reduction, wrap </p> 
			<p>Chicken salad, romaine, cranberry chutney, whole wheat </p>
			<p>Veggie wrap, artichoke, eggplant, spinach, feta, 
		      chickpea puree, wrap  </p>
			<p>Roasted turkey breast, spinach, artichoke pesto, 
		      roasted red peppers, white  </p>
			<p>Silverberger: grass fed beef, onion jam, oven dried tomatoes, romaine, aioli, gruyere, brioche</p> 
			add bacon    add mushrooms    add egg mornay 

		<p> <strong>Main Course </strong></p>

				<p>Squash Fettucine alfredo, wild mushrooms,                                                                   sage winter squash cream sauce  </p>
				<p>Roasted Chicken breast, carmelized grape risotto, 
				thyme demi  </p>
				<p>Spinach risotto, artichokes, mozzarella, roasted 
				red peppers  </p>			
				<p>Crispy salmon cake, sweet potato carrot mash, celery 
				root-apple slaw, squash jus   </p>

		<p> <strong>Sides</strong> </p>
			<p>Carmelized pepper bacon</p>    
			<p>House potatoes with mornay  </p>
			<p>Potato chips</p>  		
			<p>Truffle fries </p> 			
			</p>Market vegetable</p>

</div>