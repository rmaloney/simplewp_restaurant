<div class="box_image grid_4">
	<img src="images/beef_small.png" class="grey_border"/>
         
       <ul id="image_nav">
          <li> <a href="http://localhost/ss_simon_theme/?page_id=26">Dinner Menu </a> <a href="http://localhost/ss_simon_theme/?page_id=24"> Lunch Menu </a> <a href="http://localhost/ss_simon_theme/?page_id=20"> Brunch Menu </a></li>
       </ul>
	<h2><a href="catering" class="box_image" id="menu_link"><span>Menus</a></span></h2>
       
         

</div>


<div class="box_image grid_4">
	<img src="images/bass_small.png" class="grey_border"/>
         <ul id="about_nav">
          <li> <a href="http://localhost/ss_simon_theme/?page_id=4">About The Silverspoon </a>   <a href="http://localhost/ss_simon_theme/?page_id=39"> Chef </a></li>
         </ul>
	<h2><a href="catering" class="box_image" id="about_link"><span>About</a></span></h2>

</div>

<div class="box_image grid_4">
	<img src="images/inside_night2_small.png" class="grey_border"/>

         <ul id="catering_nav">
          <li> <a href="http://localhost/ss_simon_theme/?page_id=182">Catering </a>   <a href="http://localhost/ss_simon_theme/?page_id=184"> Private Parties </a></li>
         </ul>
	<h2><a href="catering" class="box_image" id="catering_link"><span>Catering/Parties</a></span></h2>

</div>


<div class="clear"> </div>
<br/>
<div class="grid_5" id="email_signup">

<div class="alignright">
    <a href="http://www.facebook.com/silverspooncafe?ref=ts"><img src="images/facebook.png"/> Find us on Facebook</a> 
    <a href="http://twitter.com/silvrspoonwayne"><img src="images/twitter.png"/> Twitter</a> 
</div>
    [customcontact form=2]


</div>

<div class="grid_6">
  [tpg_get_posts numerposts=2]
</div>
