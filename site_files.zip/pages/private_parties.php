<div class="grid_6">
<p>Planning a special event? We can provide an unforgettable menu and experience customized for your group's needs. We can seat up to 44 guests for full service and up to 75 for a cocktail party. Book the Silverspoon for your private party and you can expect tantalizing food, beautiful atmosphere, and outstanding service. Casual or classic, sit down meal or cocktail party, we'll work with you to meet your party's needs and budget.</p>



<p>For private party inquiries, contact General Manager Joe Johnston at the Silverspoon.</p>

Phone: 610.688.7646
</div>

<div class="grid_5 form_box">
[customcontact form=4]
</div>