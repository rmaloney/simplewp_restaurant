<div class="grid_6"
<p>Whether you're planning a special event at home, at work, or another site, we'll work with you to create a special menu for an unforgettable experience. We'll cater to your every need, whether it's an anniversary, shower, holiday or corporate function.</p>

<p>For all catering inquiries, contact General Manager Joe Johnston at the Silverspoon.</p>

Phone: 610.688.7646
</div>


<div class="grid_6 form_box">
[customcontact form=5]
</div>