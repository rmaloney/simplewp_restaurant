     <div class="grid_5">              
	<p><strong>Starter</strong></p>
		<p>Artisinal cheese plate, mostarda, mixed nuts, crostini  </p>  
		<p>Wild boar sausage, braised cabbage, mustard vinaigrette, pickled onions  
		Spinach risotto, mozzarella, roasted peppers</p>  
		<p>Smoked whitefish rillette, pumpernickel toast points, cranberry chutney  
		Steamed Mussels, tomato, fennel, garlic toast  </p>


	<p><strong>Soup and Salad</strong></p>
		<p>Soup du jour  </p>
		<p>Wild mushroom bisque, fennel croutons, chili oil  </p>
		<p>Caesar Salad, romaine, romano tuilles, anchovy  
		Mixed greens, pickled red onions, cucumber,          balsamic vinaigrette</p>  
		<p>Spinach, goat cheese, beets, walnuts, chopped bacon,    red wine vinaigrette </p> 
		<p>Poached wild shrimp, chickpea, feta, watercress,       citrus vinaigrette  </p>
		<p>add chicken     add shrimp or salmon cake </p>

		<p><strong>Flatbread</strong></p>
			<p>BBQ chicken, bacon marmalade, goat cheese, 
		          watercress, onion jam  </p>
		<p>Flatbread of the Day </p> 
</div>

<div class="grid_5">
		<p><strong>Main Course</strong></p>
			<p>Pork osso bucco, pumpkin grits, truffle duxelle, 
			cippolinni onions, natural jus  </p>
			<p>Roasted frenched chicken breast, roasted grape risotto, fresh herb demi  </p>
			<p>Squash fettucini alfredo, wild mushrooms, winter squash and sage cream </p> 
			<p>House made gnocchi, venison ragout, caramelized bacon, 
				pecorino romano</p>  
			<p>Crispy salmon, celery root and apple puree, farro, brussel sprouts, fall relish </p> 
			<p>Catch of the day </p> 
			<p>Pan seared scallops, cauliflower, grilled radicchio, spiced walnuts, citrus reduction </p> 
			<p>Grilled beef petite tender, parsnip puree, broccoli rabe, port wine reduction  </p>
			<p>Stuffed Quail, wild rice, dried cherry, parsnips, sweet potato-carrot mash, thyme jus </p>    
			<p>Five Course Chef Tasting Menu  
			(we do request the whole table�s participation)</p>


			<p>Sides</p>
				<p>Pumpkin grits </p>
				<p>Sweet potato-carrot mash </p>
				<p>Brussel sprouts and bacon </p>
				<p>Creamed spinach </p>
				<p>Grilled broccoli rabe </p>
				<p>Market vegetables </p>	

	

</div>
