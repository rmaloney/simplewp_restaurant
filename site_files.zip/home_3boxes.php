<div id ="about" class="grid_4 ">
    <p> The Silverspoon is a New American restaurant and catering business on the Main Line </p>


    <p> We constantly seek out locally grown, organic produce, sustainable fish and humanely raised meats for our menus.     </p>

<a href="#" class="button big">Menus and Information</a>


</div>




<div  id="menus_box" class="grid_4">
   <p> The Silverspoon is a New American restaurant and catering business on the Main Line </p>
</div>

<div id="catering_box" class="grid_4">
    <p> We constantly seek out locally grown, organic produce, sustainable fish and humanely raised meats for our menus.     </p>
</div>

